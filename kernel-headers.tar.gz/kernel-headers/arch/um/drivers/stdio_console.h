/* SPDX-License-Identifier: GPL-2.0 */
/* 
 * Copyright (C) 2000 Jeff Dike (jdike@karaya.com)
 */

#ifndef __STDIO_CONSOLE_H
#define __STDIO_CONSOLE_H

extern void save_console_flags(void);
#endif

