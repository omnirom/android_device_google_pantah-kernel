/* SPDX-License-Identifier: GPL-2.0 */
/* 
 * Copyright (C) 2002 Jeff Dike (jdike@karaya.com)
 */

#ifndef __UM_KMAP_TYPES_H
#define __UM_KMAP_TYPES_H

/* No more #include "asm/arch/kmap_types.h" ! */

#define KM_TYPE_NR 14

#endif
