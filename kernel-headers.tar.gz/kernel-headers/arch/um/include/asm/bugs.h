/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __UM_BUGS_H
#define __UM_BUGS_H

void check_bugs(void);

#endif
