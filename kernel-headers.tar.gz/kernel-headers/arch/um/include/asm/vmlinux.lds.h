#include <asm/thread_info.h>
#include <asm-generic/vmlinux.lds.h>
