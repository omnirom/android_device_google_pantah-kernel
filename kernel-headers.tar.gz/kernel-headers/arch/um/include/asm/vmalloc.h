#ifndef _ASM_UM_VMALLOC_H
#define _ASM_UM_VMALLOC_H

#endif /* _ASM_UM_VMALLOC_H */
