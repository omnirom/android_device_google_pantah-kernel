/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_ASM_M68K_UNISTD_H_
#define _UAPI_ASM_M68K_UNISTD_H_

#include <asm/unistd_32.h>

#endif /* _UAPI_ASM_M68K_UNISTD_H_ */
