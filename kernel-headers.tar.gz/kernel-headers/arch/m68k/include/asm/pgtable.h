/* SPDX-License-Identifier: GPL-2.0 */
#ifdef __uClinux__
#include <asm/pgtable_no.h>
#else
#include <asm/pgtable_mm.h>
#endif
