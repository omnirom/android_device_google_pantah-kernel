#ifndef _ASM_M68K_VMALLOC_H
#define _ASM_M68K_VMALLOC_H

#endif /* _ASM_M68K_VMALLOC_H */
