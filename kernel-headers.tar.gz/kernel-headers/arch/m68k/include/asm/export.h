#define KCRC_ALIGN 2
#include <asm-generic/export.h>
